//
//  NetAdRewardItem.h
//

#import <Foundation/Foundation.h>

@interface NetAdRewardItem : NSObject

@property NSString *rewardType;
@property int rewardAmount;

@end
